import React, { useState } from "react";

const products = [
  { id: 1, name: "T-Shirt 1", description: "A super comfy t-shirt for everyday wear." },
  { id: 2, name: "T-Shirt 2", description: "A stylish option for any outfit." },
  { id: 3, name: "T-Shirt 3", description: "Cool design with a relaxed fit." }
];

export default function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const handleCheckout = () => {
    alert("Checkout coming soon! Total items: " + cart.length);
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(to bottom right, #fffaf0, #fdf6e3, #f5f5dc)',
      padding: '1rem'
    }}>
      <header style={{ textAlign: 'center', padding: '2.5rem 0' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold' }}>Jasper's T-Shirts</h1>
        <p style={{ fontSize: '1.125rem', color: '#666' }}>Cool shirts. Cooler vibes.</p>
        <div style={{ marginTop: '1rem' }}>
          <button onClick={handleCheckout}>Checkout ({cart.length})</button>
          <button onClick={() => alert("Contact us at hello@jaspertees.com")} style={{ marginLeft: '1rem' }}>Contact</button>
        </div>
      </header>

      <main style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem', maxWidth: '960px', margin: '0 auto' }}>
        {products.map((product) => (
          <div key={product.id} style={{ background: '#fefcea', borderRadius: '1rem', boxShadow: '0 0.5rem 1rem rgba(0,0,0,0.1)', padding: '1rem' }}>
            <h2 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '0.5rem' }}>{product.name}</h2>
            <p style={{ fontSize: '0.875rem', color: '#666', marginBottom: '1rem' }}>{product.description}</p>
            <button onClick={() => addToCart(product)}>Add to Cart</button>
          </div>
        ))}
      </main>
    </div>
  );
}